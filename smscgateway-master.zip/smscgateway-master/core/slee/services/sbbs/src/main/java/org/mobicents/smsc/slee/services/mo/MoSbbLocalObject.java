package org.mobicents.smsc.slee.services.mo;

import javax.slee.SbbLocalObject;

public interface MoSbbLocalObject extends SbbLocalObject {
}
