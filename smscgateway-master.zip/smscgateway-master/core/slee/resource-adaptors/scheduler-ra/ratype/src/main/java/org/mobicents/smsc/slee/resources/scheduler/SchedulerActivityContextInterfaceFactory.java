package org.mobicents.smsc.slee.resources.scheduler;

public interface SchedulerActivityContextInterfaceFactory {
    javax.slee.ActivityContextInterface getActivityContextInterface(SchedulerActivity sa);
}
