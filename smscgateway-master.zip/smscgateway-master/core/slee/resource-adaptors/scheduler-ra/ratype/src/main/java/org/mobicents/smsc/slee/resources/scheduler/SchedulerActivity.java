package org.mobicents.smsc.slee.resources.scheduler;

import java.io.Serializable;

public interface SchedulerActivity extends Serializable {

	public void endActivity() throws Exception;

}
